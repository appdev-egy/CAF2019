package eg.training123.caf2019;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 */

public class DBAdapter {

    private static final String TAG = "DBAdapter";
    public static final String DATABASE_NAME = "StudentInfo";
    public static final String TABLE_NAME = "mainTable";
    public static final int DATABASE_VERSION = 1;
    public static final String[] ALL_KEYS = new String[] {"id", "name", "address", "phone", "notes"};

    static String createTable = "CREATE TABLE " +TABLE_NAME+ " (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "name varchar(255), " +
            "address varchar(255), " +
            "phone varchar(255), " +
            "notes varchar(255) " +
            ")";

    private final Context context;
    private DatabaseHelper myDBHelper;
    private SQLiteDatabase db;


    public DBAdapter(Context ctx) {
        this.context = ctx;
        myDBHelper = new DatabaseHelper(context);
    }

    // Open the database connection.
    public DBAdapter open() {
        db = myDBHelper.getWritableDatabase();
        return this;
    }

    // Close the database connection.
    public void close() {
        myDBHelper.close();
    }

    // Add a new set of values to the database.
    public long insertRow(
            String name,
            String address,
            String phone,
            String notes){

        ContentValues initialValues = new ContentValues();
        initialValues.put("name", name);
        initialValues.put("address", address);
        initialValues.put("phone",phone);
        initialValues.put("notes",notes);

        // Insert it into the database.
        return db.insert(TABLE_NAME, null, initialValues);
    }

    // Delete a row from the database, by rowId (primary key)
    public boolean deleteRow(long rowId) {
        String where = "id" + "=" + rowId;
        return db.delete(TABLE_NAME, where, null) != 0;
    }

    public void deleteAll() {
        Cursor c = getAllRows();
        long rowId = c.getColumnIndexOrThrow("id");
        if (c.moveToFirst()) {
            do {
                deleteRow(c.getLong((int) rowId));
            } while (c.moveToNext());
        }
        c.close();
    }

    // Return all data in the database.
    public Cursor getAllRows() { //21
        String where = null;
        Cursor c = 	db.query(true, TABLE_NAME, ALL_KEYS,
                where, null, null, null, null, null);
        if (c != null) {
            c.moveToFirst();
        }
        return c;
    }







    /////////////////////////////////////////////////////////////////////
    //	Private Helper Classes:
    /////////////////////////////////////////////////////////////////////

    /**
     * Private class which handles database creation and upgrading.
     * Used to handle low-level database access.
     */
    private static class DatabaseHelper extends SQLiteOpenHelper
    {
        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase _db) {
            _db.execSQL(createTable);
        }

        @Override
        public void onUpgrade(SQLiteDatabase _db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading application's database from version " + oldVersion
                    + " to " + newVersion + ", which will destroy all old data!");
            // Destroy old database:
            _db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            // Recreate new database:
            onCreate(_db);
        }
    }
}
