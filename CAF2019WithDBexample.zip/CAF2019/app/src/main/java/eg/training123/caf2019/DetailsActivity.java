package eg.training123.caf2019;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.Interpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DetailsActivity extends AppCompatActivity {

    TextView countryName, countryDescription;
    ImageView flag, kora;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        countryName = findViewById(R.id.textView);
        countryDescription = findViewById(R.id.textView2);
        flag = findViewById(R.id.imageView2);
        kora = findViewById(R.id.imageView3);
        RotateAnimation rotate = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF,
                0.5f,  Animation.RELATIVE_TO_SELF, 0.5f);
        rotate.setDuration(5000);
        rotate.setRepeatCount(Animation.INFINITE);
        kora.startAnimation(rotate);
        // Defined Array values to show in ListView
        String[] names = new String[]{
                "Senegal",
                "Tunisia",
                "Nigeria",
                "Morocco",
                "Congo",
                "Ghana",
                "Cameroon",
                "Egypt"
        };


        // Defined Array values to show in ListView
        String[] description = new String[]{
                "Senegal officially the Republic of Senegal (French: République du Sénégal), is a country in West Africa.",
                "Tunisia, officially the Republic of Tunisia, is a country in the Maghreb region of North Africa, covering 163,610 square kilometres",
                "Nigeria officially the Federal Republic of Nigeria, is a country in West Africa, bordering Niger in the north, Chad in the northeast, Cameroon in the east,",
                "Morocco officially the Kingdom of Morocco (Arabic: المملكة المغربية , romanized: al-Mamlakah al-Maghribiyah, lit. ",
                "The Democratic Republic of the Congo also known as DR Congo, the DRC, DROC, Congo-Kinshasa, East Congo, or simply the Congo, ",
                "Ghana officially the Republic of Ghana, is a country located along the Gulf of Guinea and Atlantic Ocean, in the subregion of West Africa. Spanning a land m",
                "Cameroon officially the Republic of Cameroon (French: République du Cameroun), is a country in Central Africa. It is bordered by Nigeria to the west and north",
                "Egypt officially the Arab Republic of Egypt, is a country spanning the northeast corner of Africa and southwest corner of Asia by a land bridge formed by the Sinai "
        };


        Integer[] flags = new Integer[]{
                R.drawable.f0,
                R.drawable.f1,
                R.drawable.f2,
                R.drawable.f3,
                R.drawable.f4,
                R.drawable.f5,
                R.drawable.f6,
                R.drawable.f7
        };

        Intent intent2 = getIntent();

        int item = intent2.getIntExtra("position", 99);

        countryName.setText(names[item]);
        countryDescription.setText(description[item]);
        flag.setImageResource(flags[item]);



    }
}
