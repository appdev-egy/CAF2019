package eg.training123.caf2019;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ListView listView ;
    DBAdapter myDb;
    //Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //btn = findViewById(R.id.button01);
        listView = findViewById(R.id.list01);

        openDB();

        // Defined Array values to show in ListView
        String[] values = new String[] {
                "Senegal",
                "Tunisia",
                "Nigeria",
                "Morocco",
                "Congo",
                "Ghana",
                "Cameroon",
                "Egypt"
        };

        ArrayAdapter<String> adapter =
                new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,
                        android.R.id.text1, values);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                //Toast.makeText(getBaseContext(),"position = " + i, Toast.LENGTH_LONG).show();

                Cursor mycursor = myDb.getAllRows();
                if (mycursor.moveToFirst()) {
                    do {
                        // Process the data:
                        String name = mycursor.getString(1);
                        String address = mycursor.getString(2);
                        String phone = mycursor.getString(3);
                        String notes= mycursor.getString(4);
                        Log.d("DB","\n*** name = " + name + " - address =  " + address + " - phone = " + phone );
                    } while(mycursor.moveToNext());
                }

                Intent myintnet = new Intent(MainActivity.this,DetailsActivity.class);

                myintnet.putExtra("position",i);

                startActivity(myintnet);

            }
        });


        myDb.insertRow("student1", "Shbra", "0100000", "None");
        myDb.insertRow("John", "MasrElgededa", "010002220", "None");
        myDb.insertRow("Sarah", "Giza", "333333", "None");





    }



    public void openDB() {
        myDb = new DBAdapter(this);
        myDb.open();
    }

    public void closeDB() {
        myDb.close();
    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        closeDB();

    }


}
